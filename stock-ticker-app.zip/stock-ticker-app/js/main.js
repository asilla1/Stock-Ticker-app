"use strict";


(() => {
    var API_KEY = "F98MNOBMHZNH8H3N";
    var ENDPOINT = "https://www.alphavantage.co/query?"

 //   "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&interval=1min&symbol=YESBANK&apikey={}"

/**
 * @param {Object[]} data
 * @param {object} el - The reference to the display DOM element.
 * 
 */

  var displayStock = function displayStock (data, el) {
      var symbol = el.querySelector('.detail>.symbol'),
          price = el.querySelector('.details>.price'),
          date = el.querySelector('.details>.date');


          symbol.innertext = ""
          price.innertext = 
          date.innertext = new Date(+data.dt * 1000);
  }





    document.querySelector('.frm.ticker').addEventListener('submit', function (e) {

    fetch("".concat(ENDPOINT, "=TIME_SERIES_INTRADAY").concat(location, "&interval=1min&symbol=YESBANK").concat(API_KEY)).then(function (data) 
    {
      return data.json();
    }).then(function (json) {
      displayStock(json, document.querySelector('.stock-display'))  

    })

    e.preventDefault ()
    })
})()